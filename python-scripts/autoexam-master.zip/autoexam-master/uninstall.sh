#! /bin/bash
rm /usr/bin/autoexam && echo "Removed 'autoexam' from /usr/bin/."
