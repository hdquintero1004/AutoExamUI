require 'test_helper'

class AsignaturasHelperTest < ActionView::TestCase
end
