require 'test_helper'

class LatexHelperTest < ActionView::TestCase
end
