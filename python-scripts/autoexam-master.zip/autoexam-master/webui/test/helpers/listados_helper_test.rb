require 'test_helper'

class ListadosHelperTest < ActionView::TestCase
end
