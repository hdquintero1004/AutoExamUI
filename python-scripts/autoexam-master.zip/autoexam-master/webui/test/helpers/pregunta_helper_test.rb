require 'test_helper'

class PreguntaHelperTest < ActionView::TestCase
end
