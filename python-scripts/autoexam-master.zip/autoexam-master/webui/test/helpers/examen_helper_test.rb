require 'test_helper'

class ExamenHelperTest < ActionView::TestCase
end
