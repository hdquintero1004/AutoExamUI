require 'test_helper'

class ClavePreguntaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
