require 'test_helper'

class OpcionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
