require 'test_helper'

class ClaseOpcionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
