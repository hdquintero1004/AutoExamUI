require 'test_helper'

class AsignaturaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
