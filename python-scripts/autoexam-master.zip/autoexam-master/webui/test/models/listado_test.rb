require 'test_helper'

class ListadoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
