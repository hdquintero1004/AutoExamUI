require 'test_helper'

class PreguntumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
