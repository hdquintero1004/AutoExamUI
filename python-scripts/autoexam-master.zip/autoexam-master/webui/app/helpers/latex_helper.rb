module LatexHelper
end
