class Opcion < ActiveRecord::Base
  belongs_to :preguntum
end
