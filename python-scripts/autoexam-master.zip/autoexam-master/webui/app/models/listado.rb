class Listado < ActiveRecord::Base
  belongs_to :asignatura
end
